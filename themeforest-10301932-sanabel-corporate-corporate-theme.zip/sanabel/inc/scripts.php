<?php

add_action('wp_enqueue_scripts', 'asalah_enqueue_google_font', 1);

function asalah_enqueue_google_font() {
  if (asalah_option('asalah_fonts_load_locally') != 'yes') {
    wp_enqueue_style('poppins', '//fonts.googleapis.com/css?family=Poppins:400,500,300,600,700');
  } else {
    wp_enqueue_style('poppins',  get_template_directory_uri() . "/framework/googlefonts/poppins.css");
  }
}

add_action('wp_enqueue_scripts', 'asalah_scripts', 30);
add_action('wp_head', 'asalah_ie_scripts', 30);

function asalah_ie_scripts() {
	?>
	<!--[if lt IE 9]>
	<script src="<?php echo get_template_directory_uri(); ?>/js/html5shiv.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/js/respond.min.js"></script>
	<![endif]-->
	<?php
}

add_action( 'admin_enqueue_scripts', 'asalah_admin_scripts' );
function asalah_admin_scripts($hook) {
	if ( 'nav-menus.php' != $hook ) {
        return;
    }
  global $asalah_fontello_custom_font;
  global $asalah_icomoon_custom_font;
	wp_enqueue_script('jquery');
	## Include advanced select list for icon picker
	wp_register_script( 'asalah_bootstrap-select.min', get_template_directory_uri() . '/js/bootstrap-select.min.js', array( 'jquery' ), false, true);
	wp_enqueue_script( 'asalah_bootstrap-select.min' );
	wp_register_style( 'asalah_bootstrap-select.min_css', get_template_directory_uri().'/bootstrap-select.min.css', array(), '', 'all' );
	wp_enqueue_style( 'asalah_bootstrap-select.min_css' );
  if (asalah_option('asalah_include_vector_icon') == "fontello"   && !$asalah_fontello_custom_font) {
  	wp_register_style( 'asalah_fontello_css', get_template_directory_uri().'/framework/fontello/css/fontello.css', array(), '', 'all' );
    wp_enqueue_style( 'asalah_fontello_css' );
  }
  if (asalah_option('asalah_include_vector_icon') == "icomoon"   && !$asalah_icomoon_custom_font) {
	   wp_register_style('asalah_icomoon_css', get_template_directory_uri() . '/framework/icomoon/style.css', array(), '1', 'all');
     wp_enqueue_style( 'asalah_icomoon_css' );
  }
  wp_register_style('asalah_fontawesome_css', get_template_directory_uri() . '/framework/fontawesome/css/font-awesome.min.css', array(), '', 'all');
  wp_enqueue_style( 'asalah_fontawesome_css' );
		
}

function asalah_icon_list_modal() {
  global $asalah_fontello_custom_font;
  global $asalah_icomoon_custom_font;
	?>
	<div id="my_icons_list_modal" class="modal fade" role="dialog">
	<div class="modal-dialog">

	<!-- Modal content-->
	<div class="modal-content">
		<div class="modal-body">
				<div class="input-group col-md-12">
					<input type="text" class="quicksearch" placeholder="Search" /><button id="reset">Reset</button>
          <?php if ((asalah_option('asalah_include_vector_icon') == "fontello"  && !$asalah_fontello_custom_font) || (asalah_option('asalah_include_vector_icon') == "icomoon" && !$asalah_icomoon_custom_font)) { ?>
            <select id="filters">
              <option value=".fontawesome_array">Fontawesome</option>
              <?php if (asalah_option('asalah_include_vector_icon') == "fontello"  && !$asalah_fontello_custom_font) { ?>
                <option value=".fontello_array">Fontello</option>
                <?php } else if (asalah_option('asalah_include_vector_icon') == "icomoon" && !$asalah_icomoon_custom_font) { ?>
                  <option value=".icomoon_array">Icomoon</option>
                  <?php } ?>
                </select>
                <?php } ?>
				</div>
				<ul class="fonts_array icon-list-group fontawesome_array">
					<?php 
          $icons_array = asalah_font_icons_list('fontawesome');
					foreach ($icons_array as $key => $value) {
						echo '<li class="span2" value="'.key($value).'"><a href="#"><i class="'.key($value).'"></i>'.current($value).'</a></li>';
					}
          ?>
          </ul>
          <?php
          if (asalah_option('asalah_include_vector_icon') == "fontello"  && !$asalah_fontello_custom_font) {
            echo '<ul class="fonts_array fontello_array">';
            $icons_array = asalah_font_icons_list('fontello');
            foreach ($icons_array as $key => $value) {
              echo '<li class="span2" value="'.key($value).'"><a href="#"><i class="'.key($value).'"></i>'.current($value).'</a></li>';
            }
            echo '</ul>';
          }
          if (asalah_option('asalah_include_vector_icon') == "icomoon" && !$asalah_icomoon_custom_font) {
            echo '<ul class="fonts_array icomoon_array">';
            $icons_array = asalah_font_icons_list('icomoon');
            foreach ($icons_array as $key => $value) {
              echo '<li class="span2" value="'.key($value).'"><a href="#"><i class="'.key($value).'"></i>'.current($value).'</a></li>';
            }
            echo '</ul>';
          }
            
					?>
				</ul>
		</div>
		<div class="modal-footer">
			<a type="button" class="notice-dismiss" data-dismiss="modal"></a>
		</div>
	</div>

	</div>
	</div>
	<?php
}
add_action('admin_footer-nav-menus.php', 'asalah_icon_list_modal', 100);


function asalah_scripts() {
    global $asalah_data;

    // Register All Scripts
    wp_register_script('asalah_modernizer', get_template_directory_uri() . '/js/modernizr.min.js', array('jquery'));
    wp_register_script('asalah_fullmenu', get_template_directory_uri() . '/js/fullmenu.js', array('jquery'), false, true);
    wp_register_script('asalah_googlemap', get_template_directory_uri() . '/js/googlemap.js', array( 'jquery' ), false, true );
    wp_register_script('asalah_easing', get_template_directory_uri() . '/js/onepage_scroll/jquery.easing.min.js', array( 'jquery' ), false, true );
    wp_register_script('asalah_slimscroll', get_template_directory_uri() . '/js/onepage_scroll/jquery.slimscroll.min.js', array( 'jquery' ), false, true );
    wp_register_script('asalah_onepagescroll', get_template_directory_uri() . '/js/onepage_scroll/jquery.onepage-scroll.min.js', array( 'jquery' ), false, true );

    wp_register_script('asalah_scripts', get_template_directory_uri() . '/js/asalah.js', array('jquery'), false, true);

    // Get Global Scripts
    if (asalah_cross_option("asalah_menu_style") == "full") {
        wp_enqueue_script('asalah_fullmenu');
    }
    wp_enqueue_script('asalah_modernizer');
    wp_enqueue_script('asalah_scripts');

    // Register all css
    // in_array(ICL_LANGUAGE_CODE, array("ar","he","xyz"))
    if ( is_rtl() ) {
    	wp_register_style('asalah_bootstrap_css', get_template_directory_uri() . '/framework/bootstrap/css/bootstrap.rtl.css', array(), '', 'all');
    }else{
    	wp_register_style('asalah_bootstrap_css', get_template_directory_uri() . '/framework/bootstrap/css/bootstrap.min.css', array(), '', 'all');
    }
    wp_register_style('asalah_fontawesome_css', get_template_directory_uri() . '/framework/fontawesome/css/font-awesome.min.css', array(), '', 'all');
    wp_register_style('asalah_pluginstyle_css', get_template_directory_uri() . '/pluginstyle.css', array(), '', 'all');

    if ( is_rtl() ) {
    	wp_register_style('asalah_main_style', get_template_directory_uri() . '/rtl.css', array(), '1.01', 'all');
        wp_register_style('asalah_rtl_basics_style', get_template_directory_uri() . '/rtl-basics.css', array(), '1', 'all');
    }else{
    	wp_register_style('asalah_main_style', get_bloginfo('stylesheet_url'), array(), '2.64', 'all');
    }

    wp_register_style('asalah_responsive_css', get_template_directory_uri() . '/responsive.css', array(), '1', 'all');
    wp_register_style('asalah_fancybox_css', get_template_directory_uri().'/js/fancybox/jquery.fancybox.css', array(), '', 'all' );
    wp_register_style('asalah_fancybuttons_css', get_template_directory_uri().'/js/fancybox/helpers/jquery.fancybox-buttons.css', array(), '', 'all' );
    wp_register_style('asalah_onepagescroll', get_template_directory_uri().'/js/onepage_scroll/onepage-scroll.css', array(), '', 'all' );

    // check for vector icons activated
    if (asalah_option('asalah_include_vector_icon') == "fontello") {

        // check if custom version of fontello uploaded
        $custom_fontello = get_stylesheet_directory() . '/framework/fontello/custom_fontello/css/fontello.css';
        $custom_fontello_animation = get_stylesheet_directory() . '/framework/fontello/custom_fontello/css/animation.css';
        $custom_fontello_ie7 = get_stylesheet_directory() . '/framework/fontello/custom_fontello/css/fontello-ie7.css';

        // include custom version or original version
        if (file_exists($custom_fontello)) {
          global $asalah_fontello_custom_font;
          $asalah_fontello_custom_font = true;
            wp_register_style('asalah_fontello_css', get_template_directory_uri() . '/framework/fontello/custom_fontello/css/fontello.css', array(), '1', 'all');
        } else {
            wp_register_style('asalah_fontello_css', get_template_directory_uri() . '/framework/fontello/css/fontello.css', array(), '1', 'all');
        }

        if (file_exists($custom_fontello_animation)) {
            wp_register_style('asalah_fontello_animation_css', get_template_directory_uri().'/framework/fontello/custom_fontello/css/animation.css', array(), '', 'all' );
        } else {
            wp_register_style('asalah_fontello_animation_css', get_template_directory_uri().'/framework/fontello/css/animation.css', array(), '', 'all' );
        }

        if (file_exists($custom_fontello_ie7)) {
            wp_register_style('asalah_fontello_ie7_css', get_template_directory_uri().'/framework/fontello/custom_fontello/css/fontello-ie7.css', array(), '', 'all' );
        } else {
            wp_register_style('asalah_fontello_ie7_css', get_template_directory_uri().'/framework/fontello/css/fontello-ie7.css', array(), '', 'all' );
        }

        wp_enqueue_style('asalah_fontello_css');
        wp_enqueue_style('asalah_fontello_animation_css');
        wp_enqueue_style('asalah_fontello_ie7_css');
    }elseif (asalah_option('asalah_include_vector_icon') == "icomoon") {
        // check if custom version of icomoon uploaded
        $custom_icomoon = get_stylesheet_directory() . '/framework/icomoon/custom_icomoon/style.css';

        // include custom version or original version
        if (file_exists($custom_icomoon)) {
          global $asalah_icomoon_custom_font;
          $asalah_icomoon_custom_font = true;
            wp_register_style('asalah_icomoon_css', get_template_directory_uri() . '/framework/icomoon/custom_icomoon/style.css', array(), '1', 'all');
        } else {
            wp_register_style('asalah_icomoon_css', get_template_directory_uri() . '/framework/icomoon/style.css', array(), '1', 'all');
        }
        wp_enqueue_style('asalah_icomoon_css');
    }

    // Get Global css
    wp_enqueue_style('asalah_bootstrap_css');
	wp_enqueue_style('asalah_fontawesome_css');
    wp_enqueue_style('asalah_fancybox_css');
    wp_enqueue_style('asalah_fancybuttons_css');
    wp_enqueue_style('asalah_pluginstyle_css');
    wp_enqueue_style('asalah_main_style');
    wp_enqueue_style('asalah_rtl_basics_style');
    wp_enqueue_style('asalah_responsive_css');
}



add_action('admin_enqueue_scripts', 'asalah_post_options_style');
function asalah_post_options_style() {
    wp_register_style('asalah_admin_css', get_template_directory_uri().'/admin-style.css', array(), '', 'all' );
    wp_enqueue_style('asalah_admin_css');
	if( is_admin() ) {
        // Add the color picker css file
        wp_enqueue_style( 'wp-color-picker' );
        // Include our custom jQuery file with WordPress Color Picker dependency
        wp_enqueue_script( 'custom-script-handle', get_template_directory_uri() . '/js/admin_scripts.js', array( 'wp-color-picker' ), false, true );
    }
    wp_register_script('asalah_admin', get_template_directory_uri() . '/js/admin_scripts.js', array( 'jquery' ) );
	wp_enqueue_script('asalah_admin');
}
?>