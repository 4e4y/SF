<form class="search header_search clearfix animated searchHelperFade" method="get" id="searchform" action="<?php echo esc_url(home_url('/')); ?>">
	<input class="col-md-12 search_text" id="appendedInputButton" placeholder="<?php _e( 'Hit enter to search', 'asalah' ); ?>" type="text" name="s">

	<?php if (asalah_option('asalah_search_content') == 'posts'): ?>
	<input type="hidden" name="post_type" value="post" />
	<?php elseif(asalah_option('asalah_search_content') == 'projects'): ?>
	<input type="hidden" name="post_type" value="project" />
	<?php endif; ?>
	
	<i class="fa fa-search"><input type="submit" id="searchsubmit" value="" /></i>
</form>
