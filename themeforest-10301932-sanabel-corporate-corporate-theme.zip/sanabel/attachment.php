<?php
get_header();
?>
<!-- start site content -->
<div class="site_content">

    <?php asalah_page_title_holder(); ?>

    <div class="new_section portfolio_section container-fluid">
        <div class="container">
            <div class="row">


                <?php while (have_posts()) : the_post(); ?>

                    <!-- start portfolio banner -->
                    <section class="col-md-8 main_content single_project_content">
                        <div class="project_banner row clearfix">
                            <header class="content_banner blog_post_banner col-md-12 clearfix">
                                <?php echo wp_get_attachment_image( get_the_ID(), 'large' );?>
                            </header>

                        </div>
                    </section>

                    <div class="side_content widget_area col-md-4" >

                        <?php
                        // difine project info container classes in case of full widh project layout
                        $project_info_container = '';
                        $project_description_content = '';
                        $project_details_content = '';
                        if (asalah_option("asalah_sidebar_position") != "no-sidebar" ) {
                            $project_info_container = 'row';
                            $project_description_content = 'col-md-8';
                            $project_details_content = 'col-md-4';
                        }

                        ?>
                        <div class="project_info_container clearfix <?php echo esc_attr($project_info_container); ?>">

                            <?php if ( get_the_content() != '') { ?>
                            <div class="project_description_content clearfix widget_container <?php echo esc_attr($project_description_content); ?>">
                                <div class="widget_container">
                                        <h4 class="title thin_title page-header widget_title"><?php _e('Attachment Description', 'asalah') ?></h4>
                                    <div class="textwidget widget_content">
                                        <?php the_content(); ?>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>

                            <div class="project_details_content clearfix widget_container">

                                    <div class="widget_container">

                                        <h4 class="title thin_title page-header widget_title"><?php _e('Attachment Info.', 'asalah') ?></h4>

                                        <div class="widget_content">
                                            <div class="projects_details_content">

                                              <div class="project_details_item">
                                                  <?php
                                                      echo '<p><strong>'.__('Title:', 'asalah').' : </strong>' . get_the_title(). '</p>';
                                                  ?>
                                              </div>

                                              <div class="project_details_item">
                                                  <?php
                                                      echo '<p><strong>'.__('Uploaded By', 'asalah').' : </strong>' . get_the_author(). '</p>';
                                                  ?>
                                              </div>

                                              <div class="project_details_item">
                                                  <?php
                                                      echo '<p><strong>'.__('Date', 'asalah').' : </strong>' .get_the_date(). '</p>';
                                                  ?>
                                              </div>
                                            </div>
                                        </div>
                                    </div>



                                <div class="widget_container clearfix">
                                    <div class="widget_content">
                                        <?php asalah_post_like(); ?>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                <?php endwhile; ?>

            </div>
        </div>
    </div>

</div>
<?php get_footer(); ?>