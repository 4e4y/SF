<?php
get_header();
?>
<!-- start site content -->
<div class="site_content">
    <?php
    $this_page_bread = single_tag_title( '', false );
    $this_page_title = __('Tag Archives: ', 'asalah') . single_cat_title('', false);
    asalah_page_title_holder($this_page_title, $this_page_bread, false, "no");
    ?>

    <?php
    // get project template option
    $blog_style_class = "";
    $blog_wrapper_class = "";
    if (asalah_option("asalah_blog_style")) {
        $blog_style_class .= ' style_'.asalah_option("asalah_blog_style");
    }

    if (asalah_option("asalah_blog_style") == "masonry") {
        $blog_style_class .= ' filterable_grid js-isotope';
        $blog_wrapper_class .= ' filterable_wrapper';
    }

        // get project pagination option
        $blog_pagination = "default";
        if (asalah_option("asalah_blog_pagination") == "scroll") {
            $blog_pagination = "scroll";
        }
        elseif ( asalah_option("asalah_blog_pagination") == "loadmore") {
            $blog_pagination = "loadmore";
        }
        if (asalah_post_option("asalah_blog_pagination") == "scroll") {
            $blog_pagination = "scroll";
        }
        elseif ( asalah_post_option("asalah_blog_pagination") == "loadmore") {
            $blog_pagination = "loadmore";
        }
        ?>

        <?php if ($blog_pagination != "default") : ?>
         <!-- if infinite scroll -->
        <!-- start infinite scroll -->
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                    var count = 2;
                    var total = <?php echo esc_attr($wp_query->max_num_pages); ?>;

                    <?php if ($blog_pagination == "scroll"): ?>
                    jQuery(window).scroll(function(){
                        if  (jQuery(window).scrollTop() == jQuery(document).height() - jQuery(window).height()){
                            if (count > total){
                                return false;
                            }else{
                                loadArticle(count);
                            }
                            count++;
                        }
                    });

                    <?php endif; ?>
                    <?php if ($blog_pagination == 'loadmore') : ?>
                      jQuery('.loadmore a').click( function() {
                        if (count > total) {
                            return false;
                        } else if (count == total) {
                            loadArticle(count);
                            $('.loadmore').hide('fast');
                        }else{
                            loadArticle(count);
                        }

                        count++;
                      });
                    <?php endif; ?>

                function loadArticle(pageNumber){
                        jQuery('#inifiniteLoader > img').show('fast');
                        jQuery.ajax({
                            url: "<?php echo esc_url( site_url() ) ?>/wp-admin/admin-ajax.php",
                            type:'POST',
                            data: "action=infinite_scroll&page_no="+ pageNumber + '&loop_file=content&posts_per_page=<?php echo get_option('posts_per_page'); ?>&post_type=post&tag=<?php echo esc_attr($this_page_bread); ?>',
                            success: function(html){
                                jQuery('#inifiniteLoader > img').hide('1000');

                                <?php if (asalah_option("asalah_blog_style") == "masonry"): ?>
                                var $newItems = jQuery(html)
                                $('#content').isotope( 'insert', $newItems );

                                $('#content').imagesLoaded( function() {
                                    $('#content').isotope({
                                        itemSelector : '.filterable_item',
                                    });
                                });
                                <?php else: ?>
                                jQuery("#content").append(html);
                                jQuery(".video_fit_container").fitVids();  // This will be the div where our content will be loaded
                                <?php endif; ?>
                            }
                        });
                    return false;
                }
        });
    </script>
    <!-- end infinite scroll -->
    <?php endif; ?>
    <div class="new_section blog_section container-fluid">
        <div class="container">
            <?php
            $main_row_class = "";
            if (asalah_cross_option('asalah_post_sticky_sidebar') == "yes") {
                $main_row_class = "asalah_sticky_sidebar_container";
            }
            ?>
            <div class="row content_main_row <?php echo esc_attr($main_row_class); ?>">
                <div class="blog_main_content_layout blog_posts_wrapper <?php echo esc_attr($blog_wrapper_class); ?> <?php echo asalah_default_content_class(); ?>">
                    <!-- if page title is not enabled add secondary page title here -->
                    <?php if (asalah_option("asalah_enable_pagetitle") == "no"): ?>
                        <h1 class="title secondary_page_title"><?php printf( __( 'Tag Archives: %s', 'asalah' ), single_tag_title( '', false ) ); ?></h1>
                    <?php endif; ?>
                    <!-- endif for checking if page title is not enabled -->

                    <div  id="content" class="main_content blog_main_content clearfix <?php echo esc_attr($blog_style_class); ?>"  data-isotope-options='{ "itemSelector": ".filterable_item" }'>
                    <?php if ($wp_query->have_posts()) : ?>
                        <?php get_template_part('content'); ?>
                    <?php else : ?>
                        <?php get_template_part('content', 'none'); ?>
                    <?php endif; ?>
                    </div>

                    <?php if ($blog_pagination == "scroll"): ?>
                        <div id="inifiniteLoader"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/ajax-loader.gif" /></div>
                    <?php elseif ($blog_pagination == "loadmore"): ?>
                        <?php if (get_next_posts_link()) {?><div class='loadmore'><a class="btn btn-default" href="javascript: void(0)">Load More <div id="inifiniteLoader"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/ajax-loader.gif" /></div></a></div><?php } ?>
                    <?php else: ?>
                        <?php asalah_bootstrap_pagination(); ?>
                    <?php endif; ?>
                    <?php wp_reset_query(); ?>
                </div> <!-- end main_content -->

                <?php if (asalah_option("asalah_sidebar_position") != "no-sidebar" ): ?>
                    <div class="side_content <?php echo asalah_default_sidebar_class(); ?>">
                        <?php get_sidebar(); ?>
                    </div>
                <?php endif; ?>

            </div> <!-- end row -->
        </div> <!-- end container -->
    </div>  <!-- end new_section blog_section -->
</div>

<?php get_footer(); ?>