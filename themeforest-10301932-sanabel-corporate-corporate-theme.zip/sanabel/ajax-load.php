<?php

define('WP_USE_THEMES', false);
$wpdir = explode( "wp-content" , __FILE__ );
require $wpdir[0] . "wp-load.php";

$loopFile        = $_POST['loop_file'];
$paged           = $_POST['page_no'];
$posts_per_cycle  = $_POST['posts_per_page'];
$post_type  = $_POST['post_type'];
$ajaxpost_id = $_POST['pageid'];
$tag = $_POST['tag'];
if ( isset($_POST['exclude']) && $_POST['exclude'] != '' ) {
  $excluded_array = explode(",", $_POST['exclude']);
  $args['post__not_in'] = $excluded_array;
}
if ( isset( $_GET[ 'wpml_lang' ] ) ) {
    do_action( 'wpml_switch_language',  $_GET[ 'wpml_lang' ] ); // switch the content language
}

# Load the posts
$args['posts_per_page'] = $posts_per_cycle;
$args['paged'] = $paged;
$args['post_  type'] = $post_type;
if ($tag != '') {
$args['tagportfolio'] = $tag;
}
if (isset($ajaxpost_id)) {
    $current_post_id = $ajaxpost_id;
}
$portfolio_thumbnail_option = "portfolio";
if (asalah_option("asalah_portfolio_thumnails") == "masonry") {
    $portfolio_thumbnail_option = "masonry";
}
if (asalah_post_option("asalah_portfolio_thumnails", $current_post_id) == "default") {
    $portfolio_thumbnail_option = "portfolio";
}elseif (asalah_post_option("asalah_portfolio_thumnails", $current_post_id) == "masonry") {
    $portfolio_thumbnail_option = "masonry";
}

$portfolio_column = "one_third";
if (asalah_option("asalah_portfolio_columns")) {
   $portfolio_column = asalah_option("asalah_portfolio_columns");
}
if (asalah_post_option("asalah_portfolio_columns", $current_post_id)) {
   $portfolio_column = asalah_post_option("asalah_portfolio_columns", $current_post_id);
}
$wp_query = new WP_Query($args);

if ($loopFile == 'content-project.php') {
  while (have_posts()) : the_post(); ?>
      <?php
      $project_tags = get_the_term_list( $post->ID, 'tagportfolio', '',', ','');

      // define portfolio thumbnail option
      $output = '';
      $output .= '<li class="'.$portfolio_column.' portfolio_grid_list filterable_item clearfix grid_list portfoliotagfilterall '.asalah_portfolio_tag().'"  data-projectid="' .$post->ID.'">';
              $output .= '<figure class="portfolio_figure overlay_fade">';
      $output .= '<a href="'.get_permalink().'">';
          if (get_the_post_thumbnail($post->ID)) {
            $output .= get_the_post_thumbnail($post->ID, $portfolio_thumbnail_option, array( 'class' => 'img-responsive' ) );
          }else{
            // if no project thumbnail show default thumbnail

            $output .= '<img src="'.asalah_option('asalah_default_project_thumbnail').'" class="img-responsive"/>';

          }
          $output .= '<div class="overlay_color"></div>';
      $output .= '</a>';

      $output .= '<a href="'.get_permalink().'">';
        $output .= '<figcaption  class="portfolio_caption">';
                          $output .= '<h4 class="title">'.get_the_title().'</h4>'; // seperate title into two parts
                          $output .= '<span class="portfolio_category">'.strip_tags($project_tags).'</span>';
                          $output .= '<p class="project_text">'.excerpt(30).'</p>';
                      $output .= '</figcaption>'; // end portfolio_caption
      $output .= '</a>';
              $output .= '</figure>'; // end portfolio_figure overlay_fade
          $output .= '</li>'; // portfolio_grid_list

          echo balanceTags($output);
      ?>
  <?php endwhile;
} else if ($loopFile == 'content-projectfull.php') {
while (have_posts()) : the_post(); ?>
      <?php
      $output = '';
      $output .= '<li class="'.$portfolio_column.' portfolio_grid_list filterable_item clearfix grid_list portfoliotagfilterall '.asalah_portfolio_tag().'" data-projectid="' .$post->ID.'">';
              $output .= '<figure class="portfolio_figure overlay_fade">';
                  if (get_the_post_thumbnail($post->ID)) {
                    $output .= get_the_post_thumbnail($post->ID, $portfolio_thumbnail_option, array( 'class' => 'img-responsive' ) );
                  }else{
                    // if no project thumbnail show default thumbnail
                    $output .= '<img src="'.asalah_option('asalah_default_project_thumbnail').'" class="img-responsive"/>';
                  }
      $output .= '<div class="overlay_color"></div>';
                  $output .= '<a href="'.get_permalink().'">';
        $output .= '<figcaption  class="portfolio_caption">';
                          $output .= '<h4 class="title">'.get_the_title().'</h4>'; // seperate title into two parts
                      $output .= '</figcaption>'; // end portfolio_caption
      $output .= '</a>';
              $output .= '</figure>'; // end portfolio_figure overlay_fade
          $output .= '</li>'; // portfolio_grid_list

          echo balanceTags($output);
      ?>
  <?php endwhile;
}
?>