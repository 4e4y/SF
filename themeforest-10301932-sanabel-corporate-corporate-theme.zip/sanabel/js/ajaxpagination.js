function readyFn(jQuery) {

	"use strict";

/* --------
 apply ajax loading posts
 -------------------------------------------
jQuery(".portfolio_filter_options ul a").on('click', function(){

  var ajax_nav_container = jQuery(this);
  var ajaxcontainer = jQuery('.ajax_content_container');
  var posttype = ajax_nav_container.attr('data-posttype');
  var postsperpage = ajax_nav_container.attr('data-postsperpage');
  var loopfile = ajax_nav_container.attr('data-loopfile');
  var totalpages = ( ajax_nav_container.attr('data-totalpages') );
  var count = parseInt( ajax_nav_container.attr('data-cycle') );
  var lang_data = ajax_nav_container.attr('data-lang');
  var pageid = ajax_nav_container.attr('data-pageid');
	var exclude = ajax_nav_container.attr('data-exclude');
	var tag = ajax_nav_container.attr('data-tag');




  if ( jQuery(this).hasClass('ajax_load_more') && (count) <= totalpages ) {
    count++;
    ajax_nav_container.attr('data-cycle', count);
    loadArticle(count, posttype, postsperpage, loopfile, ajaxcontainer, pageid);

    if (count == totalpages) {
      ajax_nav_container.hide();
    }


  } else {
    return false;
  }
	jQuery(this).html('Load More');
});
*/
jQuery( document ).ready( readyFn );