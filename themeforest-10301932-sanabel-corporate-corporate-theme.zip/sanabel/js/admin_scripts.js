(function( $ ) {

    // Add Color Picker to all inputs that have 'color-field' class
    $(function() {
        $('.asalah_color').wpColorPicker();
    });

    jQuery(document).on('click', '.aq_upload_button', function(event) {
        var $clicked = jQuery(this), frame,
            input_id = $clicked.prev().attr('id'),
            media_type = $clicked.attr('rel');

        event.preventDefault();

        // If the media frame already exists, reopen it.
        if ( frame ) {
            frame.open();
            return;
        }

        // Create the media frame.
        frame = wp.media.frames.aq_media_uploader = wp.media({
            // Set the media type
            library: {
                type: media_type
            },
            view: {

            }
        });

        // When an image is selected, run a callback.
        frame.on( 'select', function() {
            // Grab the selected attachment.
            var attachment = frame.state().get('selection').first();

            jQuery('#' + input_id).val(attachment.attributes.url);

            if(media_type == 'image') jQuery('#' + input_id).parent().parent().parent().find('.screenshot img').attr('src', attachment.attributes.url);

        });

        frame.open();
    });

// reorganize mete on page load
var selected_page_template = jQuery("select[name='page_template'] option:selected ").val();
// show portfolio template box in case portfolio page selected
if (selected_page_template == 'page-templates/portfolio.php' || selected_page_template == 'page-templates/portfolio-full.php' ) {
	jQuery("#asalah_blog_template_box").slideUp('300');
	jQuery("#asalah_portfolio_template_box").slideDown('300');
} else if (selected_page_template == 'page-templates/blog.php') {
	jQuery("#asalah_portfolio_template_box").slideUp('300');
	jQuery("#asalah_blog_template_box").slideDown('300');
}
// reorganize other meta options
if (selected_page_template != '') {
	jQuery("[data_mother_templates]").not("[data_mother_templates*='"+selected_page_template+"']").slideUp('300');
	jQuery("[data_mother_templates*='"+selected_page_template+"']").slideDown('300');
}

// reorganize meta on template change
jQuery("select[name='page_template']").change(function(){
	var changed_page_template = jQuery(this).val();
	// hide portfolio and blog template boxes before checking
	// show portfolio template box in case portfolio page selected

	if (changed_page_template == 'page-templates/portfolio.php' || changed_page_template == 'page-templates/portfolio-full.php' ) {
		jQuery("#asalah_blog_template_box").slideUp('300');
		jQuery("#asalah_portfolio_template_box").slideDown('300');
	}else if (changed_page_template == 'page-templates/blog.php') {
		jQuery("#asalah_portfolio_template_box").slideUp('300');
		jQuery("#asalah_blog_template_box").slideDown('300');
	} else {
		jQuery("#asalah_portfolio_template_box").slideUp('300');
		jQuery("#asalah_blog_template_box").slideUp('300');
	}
	jQuery("[data_mother_templates]").not("[data_mother_templates*='"+changed_page_template+"']").slideUp('300');
	jQuery("[data_mother_templates*='"+changed_page_template+"']").slideDown('300');
});
function escapeRegExp(str) {
    return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
}
function replaceAll(str, find, replace) {
  return str.replace(new RegExp(escapeRegExp(find), 'g'), replace);
}

jQuery(document).on('click', 'a#convert_vc', function(event) {
  event.preventDefault();
  var shortcodes_content = jQuery('#wp-content-editor-container .wp-editor-area').text();

  if (shortcodes_content.indexOf('[section') != -1) {
    var start_index = shortcodes_content.indexOf('[section');
    var mid_index = shortcodes_content.indexOf(']', start_index);
    var end_index = shortcodes_content.indexOf('[/section]', mid_index);
    var search_area = shortcodes_content.slice((mid_index+1), end_index);
    if (search_area.indexOf('[row]') == -1) {
      var end_area = '[vc_column]'.concat(search_area);
      end_area = end_area.concat('[/vc_column]');
      shortcodes_content = replaceAll(shortcodes_content, search_area, end_area);
    }
    var search_loop = 1;
    while (search_loop != 0) {
      if (shortcodes_content.indexOf('[section', end_index) != -1) {
        var start_index = shortcodes_content.indexOf('[section', end_index);
        var mid_index = shortcodes_content.indexOf(']', start_index);
        var end_index = shortcodes_content.indexOf('[/section]', mid_index);
        var search_area = shortcodes_content.slice((mid_index+1), end_index);
        if (search_area.indexOf('[row]') == -1) {
          var end_area = '[vc_column]'.concat(search_area);
          end_area = end_area.concat('[/vc_column]');
          shortcodes_content = replaceAll(shortcodes_content, search_area, end_area);
        }
      } else {
        search_loop = 0;
      }
    }
  }
  shortcodes_content = replaceAll(shortcodes_content,'[section', '[vc_row');
  shortcodes_content = replaceAll(shortcodes_content,'/section]', '/vc_row]');
  shortcodes_content = replaceAll(shortcodes_content,'[row]', '');
  shortcodes_content = replaceAll(shortcodes_content,'[/row]', '');
  shortcodes_content = replaceAll(shortcodes_content,'[inner_row]', '[vc_row_inner]');
  shortcodes_content = replaceAll(shortcodes_content,'[/inner_row]', '[/vc_row_inner]');
  shortcodes_content = replaceAll(shortcodes_content,'[one_half]', '[vc_column width="1/2"]');
  shortcodes_content = replaceAll(shortcodes_content,'[/one_half]', '[/vc_column]');
  shortcodes_content = replaceAll(shortcodes_content,'[one_third]', '[vc_column width="1/3"]');
  shortcodes_content = replaceAll(shortcodes_content,'[/one_third]', '[/vc_column]');
  shortcodes_content = replaceAll(shortcodes_content,'[two_third]', '[vc_column width="2/3"]');
  shortcodes_content = replaceAll(shortcodes_content,'[/two_third]', '[/vc_column]');
  shortcodes_content = replaceAll(shortcodes_content,'[one_fourth]', '[vc_column width="1/4"]');
  shortcodes_content = replaceAll(shortcodes_content,'[/one_fourth]', '[/vc_column]');
  shortcodes_content = replaceAll(shortcodes_content,'[three_fourth]', '[vc_column width="3/4"]');
  shortcodes_content = replaceAll(shortcodes_content,'[/three_fourth]', '[/vc_column]');
  shortcodes_content = replaceAll(shortcodes_content,'[one_fifth]', '[vc_column width="2/12"]');
  shortcodes_content = replaceAll(shortcodes_content,'[/one_fifth]', '[/vc_column]');
  shortcodes_content = replaceAll(shortcodes_content,'[two_fifth]', '[vc_column width="4/12"]');
  shortcodes_content = replaceAll(shortcodes_content,'[/two_fifth]', '[/vc_column]');
  shortcodes_content = replaceAll(shortcodes_content,'[three_fifth]', '[vc_column width="6/12"]');
  shortcodes_content = replaceAll(shortcodes_content,'[/three_fifth]', '[/vc_column]');
  shortcodes_content = replaceAll(shortcodes_content,'[four_fifth]', '[vc_column width="10/12"]');
  shortcodes_content = replaceAll(shortcodes_content,'[/four_fifth]', '[/vc_column]');
  shortcodes_content = replaceAll(shortcodes_content,'[one_sixth]', '[vc_column width="1/6"]');
  shortcodes_content = replaceAll(shortcodes_content,'[/one_sixth]', '[/vc_column]');
  shortcodes_content = replaceAll(shortcodes_content,'[five_sixth]', '[vc_column width="5/6"]');
  shortcodes_content = replaceAll(shortcodes_content,'[/five_sixth]', '[/vc_column]');
  shortcodes_content = replaceAll(shortcodes_content,'[column ', '[vc_column ');
  shortcodes_content = replaceAll(shortcodes_content,'[/column]', '[/vc_column]');
  shortcodes_content = replaceAll(shortcodes_content,'[full_column]', '[vc_column]');
  shortcodes_content = replaceAll(shortcodes_content,'[/full_column]', '[/vc_column]');
  if (shortcodes_content.indexOf('vc_row_inner') != -1) {
    var start_index = shortcodes_content.indexOf('[vc_row_inner]');
    var end_index = shortcodes_content.indexOf('[/vc_row_inner]', start_index);
    var search_area = shortcodes_content.slice(start_index, end_index);
    var end_area = replaceAll(search_area, '[vc_column ', '[vc_column_inner ');
    end_area = replaceAll(end_area, '[/vc_column]', '[/vc_column_inner]');
    shortcodes_content = replaceAll(shortcodes_content, search_area, end_area);
    var search_loop = 1;
    while (search_loop != 0) {
      if (shortcodes_content.indexOf('[vc_row_inner]', end_index) != -1) {
        var start_index = shortcodes_content.indexOf('[vc_row_inner]', end_index);
        var end_index = shortcodes_content.indexOf('[/vc_row_inner]', start_index);
        var search_area = shortcodes_content.slice(start_index, end_index);
        var end_area = replaceAll(search_area, '[vc_column ', '[vc_column_inner ');
        end_area = replaceAll(end_area, '[/vc_column]', '[/vc_column_inner]');
        shortcodes_content = replaceAll(shortcodes_content, search_area, end_area);
      } else {
        search_loop = 0;
      }
    }
  }

   jQuery('#wp-content-editor-container .wp-editor-area').text(shortcodes_content);

});

})( jQuery );